// script.js - petit comportement pour menu et formulaire
document.getElementById('year').textContent = new Date().getFullYear();

const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuToggle && menuToggle.addEventListener('click', ()=> {
  if (nav.style.display === 'flex') nav.style.display = 'none';
  else nav.style.display = 'flex';
});

// Simple handler pour le formulaire (montrer un message)
const form = document.getElementById('contactForm');
form && form.addEventListener('submit', (e)=>{
  e.preventDefault();
  alert('Merci — votre message a été reçu (demo). Remplacez l'action par un vrai backend pour envoyer.');
  form.reset();
});
