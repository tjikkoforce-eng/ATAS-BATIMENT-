README - ATAS BATIMENT (Stripe dynamique)

Ce site est prêt pour GitHub Pages ou Netlify.

Infos personnalisées:
- Nom: ATAS BATIMENT
- Sous-titre: Matériaux de construction
- Email contact: tjikkoforce@gmail.com
- Don Stripe: bouton dynamique permettant au donateur de choisir le montant

Étapes pour mettre en ligne avec GitHub Pages:
1. Créez un compte GitHub (si vous n'en avez pas).
2. Créez un nouveau dépôt, par ex. "atas-batiment-site".
3. Uploadez les fichiers index.html, style.css, script.js, README.txt.
4. Dans les paramètres du dépôt -> Pages -> Source -> choisissez "main branch" -> /root.
5. Votre site sera disponible sur https://<votre-nom>.github.io/atas-batiment-site

⚠️ Pensez à:
- Remplacer le lien Stripe dans index.html (https://donate.stripe.com/test_dynamic_example) par le lien généré dans votre tableau de bord Stripe avec l’option "client choisit le montant".
- Créer un compte gratuit sur Formspree.io et remplacer l’URL du formulaire.
